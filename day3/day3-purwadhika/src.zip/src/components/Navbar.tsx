export default function Navbar() {
  return (
    <div className="nav">
      <h3>Logo</h3>
      <div className="menu">
        <a href="/">Home</a>
        <a href="/Product">Product</a>
        <a href="/About">About</a>
      </div>
    </div>
  );
}

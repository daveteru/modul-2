import Navbar from "../components/navbar";

export default function Home() {
  return (
    <div>
      <Navbar />
      <div className="wrap" style={{ backgroundColor: "#f0edeb" }}>
        <h1
          style={{
            fontFamily: "'Adobe Garamond Pro'",
            fontWeight: "300",
            fontStyle: "italic",
            color: "maroon",
          }}
        >
        Welcome user, to React.
        </h1>{" "}
        <br />
        <a href="/about">to About</a>
        <br />
        <a href="/product">to Product</a>
      </div>
    </div>
  );
}

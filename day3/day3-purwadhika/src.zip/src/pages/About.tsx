import Navbar from "../components/navbar";

export default function About() {
  return (
    <div>
      <Navbar />
      <h1>about</h1>
      <a href="/">to Home</a>
    </div>
  );
}

import Navbar from "../components/navbar";

export default function Product() {
  return (
    <div>
      <Navbar />
      <h1>product</h1>
      <a href="/">to Home</a>
    </div>
  );
}
